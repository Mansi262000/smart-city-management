def notify(severity: str, message: str):
    # Replace with Twilio/SendGrid/etc.
    print(f"[NOTIFY] {severity.upper()}: {message}")
